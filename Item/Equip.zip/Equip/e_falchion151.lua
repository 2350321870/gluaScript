ITEMINFO = {
	icon = 1518,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "ǿ�ߵ�",
	["required/level"] = 40,
	["required/class"] = "shen",
	BindType = "ImmediatelyBind",
	dresstype = "40",
	dresscolor = 0,
	max_damage = 220,
	value = 38800,
	offer=900,  --������Ҫ�ﹱ
}


