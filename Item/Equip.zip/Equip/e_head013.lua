ITEMINFO = {
	icon = 25,
	icon_f = 26,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "���ƹ�",
	["required/level"] = 37,
	--["required/gender"] = "����",
	max_mp = 200,
	defense = 21,
	value = 16666,
}


