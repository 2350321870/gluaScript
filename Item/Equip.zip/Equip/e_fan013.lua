ITEMINFO = {
	icon = 1763,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "����",
	["required/level"] = 80,
	["required/class"] = "xian",
	max_damage = 297,
	value = 267777,
}


