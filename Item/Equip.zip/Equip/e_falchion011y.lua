ITEMINFO = {
	icon = 1511,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "�ĵ�",
	["required/level"] = 35,
	["required/class"] = "shen",
	max_damage = 185,
	value = 7200,
}


