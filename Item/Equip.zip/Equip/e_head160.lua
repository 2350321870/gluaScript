ITEMINFO = {
	icon = 55,
	icon_f = 56,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "���ܿ�",
	["required/level"] = 70,
	--["required/gender"] = "����",
	BindType = "Used_Bind",
	dresstype = "703",
	dresscolor = 1,
	max_mp = 410,
	value = 700000,
}


