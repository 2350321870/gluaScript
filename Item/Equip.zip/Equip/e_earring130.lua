ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "@2������[+9]@0",
	["required/level"] = 65,
	max_damage = 9,
	defense = 23,
	max_mp = 390,
	max_hp = 110,
	str = 11,
	value = 200,
}

