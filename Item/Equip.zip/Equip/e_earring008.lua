ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "������׹",
	["required/level"] = 45,
	max_hp = 260,
	str=24,
	value = 5000,
}


