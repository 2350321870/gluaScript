ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "������",
	["required/level"] = 50,
	["required/class"] = "xian",
	BindType = "Used_Bind",
	dresstype = "501",
	dresscolor = 0,
	max_damage = 58,
	no_bothhands = 1,
	value = 122200,
	
}


