ITEMINFO = {
	icon = 1524,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "̰��",
	["required/level"] = 72,
	["required/class"] = "shen",
	BindType = "Used_Bind",
	max_damage = 700,
	value = 628888,
}


