ITEMINFO = {
	list_icon = 29,
	type = "book",
	wield_position = 2,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "���龭[��]",
	["required/level"] = 62,
	["required/class"] = "xian",
	max_damage = 55,
	["apply/hp"] = 43,
	value = 100,
}

