ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "�������",
	["required/level"] = 9,
	max_hp = 80,
	str=6,
	value = 200,
}


