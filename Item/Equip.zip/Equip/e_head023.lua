ITEMINFO = {
	icon = 45,
	icon_f = 46,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "���¿�",
	["required/level"] = 67,
	--["required/gender"] = "����",
	max_mp = 350,
	defense = 55,
	value = 210000,
}


