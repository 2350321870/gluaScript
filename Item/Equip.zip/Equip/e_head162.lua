ITEMINFO = {
	icon = 63,
	icon_f = 64,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "��ʥ��",
	["required/level"] = 80,
	--["required/gender"] = "����",
	dresstype = "802",
	dresscolor = 2,
	max_mp = 410,
	value = 700000,
}


