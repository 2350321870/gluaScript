ITEMINFO = {
	list_icon = 59,
	type = "glove",
	wield_position = 7,
	is_bag_item = 1,
	name = "�ϵ硾+0��",
	--["required/level"] = 60,
	BindType = "Used_Bind",
	speed = 1,--�ٶ�
	riding = 5,--����
	value = 10050,
	max_hp=8,
}
