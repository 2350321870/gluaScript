ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "��ӵ��׹",
	["required/level"] = 60,
	BindType = "ImmediatelyBind",
	dresstype = "704",
	dresscolor = 0,
	max_hp = 432,
	str=25,
	value = 45000,
	offer=700,  --������Ҫ�ﹱ
}


