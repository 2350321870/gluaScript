ITEMINFO = {
	icon = 1757,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "��ѩ��",
	["required/level"] = 44,
	["required/class"] = "xian",
	max_damage = 171,
	value = 23456,
}


