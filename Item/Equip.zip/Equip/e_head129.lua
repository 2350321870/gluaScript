ITEMINFO = {
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "@2������[+8]@0",
	["required/level"] = 65,
	max_mp = 60,
	max_hp = 354,
	str = 11,
	dex = 10,
	int = 11,
	value = 200,
}

