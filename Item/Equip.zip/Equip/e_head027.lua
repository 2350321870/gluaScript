ITEMINFO = {
	icon = 53,
	icon_f = 54,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "���ȹ�",
	["required/level"] = 79,
	--["required/gender"] = "����",
	max_mp = 410,
	defense = 73,
	value = 281111,
}


