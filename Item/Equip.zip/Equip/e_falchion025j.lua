ITEMINFO = {
	icon = 1525,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "�����",
	["required/level"] = 79,
	["required/class"] = "shen",
	max_damage = 370,
	value = 838888,
}


