ITEMINFO = {
	icon = 405,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "���˿��",
	["required/level"] = 43,
	defense = 38,
	value = 33888,

}


