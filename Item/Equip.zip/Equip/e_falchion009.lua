ITEMINFO = {
	icon = 1509,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "����ն",
	["required/level"] = 32,
	["required/class"] = "shen",
	max_damage = 159,
	value = 3300,
}


