ITEMINFO = {
	icon = 403,
	icon_f = 419,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "��Ӱ��",
	["required/level"] = 82,
	defense = 111,
	value = 1400000,
}


