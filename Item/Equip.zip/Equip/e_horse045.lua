ITEMINFO = {
	list_icon = 59,
	type = "glove",
	wield_position = 7,
	is_bag_item = 1,
	name = "���ס�+5��",
	--["required/level"] = 50,
	BindType = "Used_Bind",
	speed = 4,--�ٶ�
	riding = 4,--����
	value = 10045,
	max_hp=146,
	str=9,
}
