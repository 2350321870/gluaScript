ITEMINFO = {
	--icon = 98,--9,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "����ͷ��",
	["required/level"] = 13,
	--["required/gender"] = "����",
	useful_time_use=604800,
	max_mp = 80,
	value = 410,
}


