ITEMINFO = {
	icon = 1530,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "����",
	["required/level"] = 90,
	["required/class"] = "shen",
	max_damage = 436,
	value = 344444,
}


