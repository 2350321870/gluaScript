ITEMINFO = {
	list_icon = 59,
	type = "glove",
	wield_position = 7,
	is_bag_item = 1,
	name = "���ס�+9��",
	--["required/level"] = 50,
	BindType = "Used_Bind",
	speed = 6,--�ٶ�
	riding = 4,--����
	value = 10049,
	max_hp=1000,
	str=53,
}
