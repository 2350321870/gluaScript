ITEMINFO = {
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "������[��]",
	["required/level"] = 62,
	defense = 13,
	["apply/hp"] = 330,
	value = 100,
}

