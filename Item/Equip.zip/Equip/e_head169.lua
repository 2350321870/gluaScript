ITEMINFO = {
	icon = 31,
	icon_f = 32,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "ʥ�����",
	["required/level"] = 70,
	--["required/gender"] = "����",
	BindType = "ImmediatelyBind",
	dresstype = "705",
	dresscolor = 0,
	max_mp = 492.48,
	defense = 37,
	value = 48000,
	offer=300,  --������Ҫ�ﹱ
}


