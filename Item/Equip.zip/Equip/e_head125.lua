ITEMINFO = {
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "@2������[+4]@0",
	["required/level"] = 65,
	max_hp = 342,
	str = 7,
	dex = 6,
	int = 7,
	value = 200,
}

