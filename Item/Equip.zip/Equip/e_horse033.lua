ITEMINFO = {
	list_icon = 59,
	type = "glove",
	wield_position = 7,
	is_bag_item = 1,
	name = "��Ӱ��+3��",
	--["required/level"] = 40,
	BindType = "Used_Bind",
	speed = 3,--�ٶ�
	riding = 3,--����
	value = 10033,
	max_hp=65,
	dex=3,
}
