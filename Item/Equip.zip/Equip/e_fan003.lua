ITEMINFO = {
	icon = 1753,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "籾���",
	["required/level"] = 20,
	["required/class"] = "xian",
	max_damage = 87,
	value = 900,
}


