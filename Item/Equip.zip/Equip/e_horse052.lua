ITEMINFO = {
	list_icon = 59,
	type = "glove",
	wield_position = 7,
	is_bag_item = 1,
	name = "�ϵ硾+2��",
	--["required/level"] = 60,
	BindType = "Used_Bind",
	speed = 2,--�ٶ�
	riding = 5,--����
	value = 10052,
	max_hp=32,
	int=2,
}
