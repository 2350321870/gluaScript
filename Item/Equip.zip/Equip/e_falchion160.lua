ITEMINFO = {
	icon = 1520,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "���ܵ�",
	["required/level"] = 70,
	["required/class"] = "shen",
	BindType = "Used_Bind",
	dresstype = "703",
	dresscolor = 1,
	max_damage = 25,
	value = 50,
}


