ITEMINFO = {
	icon = 422,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "�ƾ���",
	["required/level"] = 80,
	BindType = "Used_Bind",
	dresstype = "802",
	dresscolor = 2,
	defense = 114,
	value = 1200030,

}


