ITEMINFO = {
	icon = 399,
	icon_f = 315,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "@2����ս��[+4]@0",
	["required/level"] = 65,
	defense = 81,
	max_mp = 55,
	max_hp = 52,
	str = 5,
	value = 200,
}

