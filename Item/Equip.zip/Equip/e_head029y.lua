ITEMINFO = {
	--icon = 98,--57,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "Ѫ��ñ",
	["required/level"] = 82,
	--["required/gender"] = "����",
	max_mp = 440,
	value = 920000,
}


