ITEMINFO = {
	--icon = 98,--25,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "�����",
	["required/level"] = 34,
	--["required/gender"] = "����",
	max_mp = 200,
	value = 20000,
}


