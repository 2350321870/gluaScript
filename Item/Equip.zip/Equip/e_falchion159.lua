ITEMINFO = {
	icon = 1520,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "���䵶",
	["required/level"] = 70,
	["required/class"] = "shen",
	BindType = "Used_Bind",
	dresstype = "702",
	dresscolor = 1
	max_damage = 320,
	value = 300050,
}


