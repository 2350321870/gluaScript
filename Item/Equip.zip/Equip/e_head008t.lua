ITEMINFO = {
	--icon = 98,--15,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "ī���",
	useful_time_use=604800,
	["required/level"] = 22,
	--["required/gender"] = "����",
	max_mp = 125,
	value = 2100,
}


