ITEMINFO = {
	icon = 1504,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "ս��",
	["required/level"] = 12,
	["required/class"] = "shen",
	BindType = "ImmediatelyBind",
	max_damage = 174,
	value = 350,
}


