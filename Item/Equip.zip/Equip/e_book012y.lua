ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "ī��",
	["required/level"] = 75,
	["required/class"] = "xian",
	max_damage = 75,
	no_bothhands = 1,
	value = 80000,
	
}


