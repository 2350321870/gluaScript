ITEMINFO = {
	icon = 403,
	icon_f = 414,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "��ͭ��",
	useful_time_use=604800,
	["required/level"] = 7,
	defense = 6,
	value = 120,

}


