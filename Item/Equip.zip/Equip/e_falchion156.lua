ITEMINFO = {
	icon = 1528,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "�ȷ�ն",
	["required/level"] = 60,
	["required/class"] = "shen",
	dresstype = "603",
	dresscolor = 1,
	max_damage = 310,
	value = 99999,
}


