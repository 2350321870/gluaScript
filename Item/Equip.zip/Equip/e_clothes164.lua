ITEMINFO = {
	icon = 418,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "Х����",
	["required/level"] = 80,
	BindType = "Used_Bind",
	dresstype = "804",
	dresscolor = 2,
	defense = 105,
	value = 1200030,

}


