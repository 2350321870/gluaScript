ITEMINFO = {
	list_icon = 29,
	type = "book",
	wield_position = 2,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "@2�侭[+8]@0",
	["required/level"] = 65,
	["required/class"] = "xian",
	max_damage = 66,
	defense = 11,
	max_mp = 69,
	max_hp = 37,
	int = 10,
	value = 200,
}

