ITEMINFO = {
	icon = 1761,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "����",
	["required/level"] = 68,
	["required/class"] = "xian",
	max_damage = 255,
	value = 188888,
}


