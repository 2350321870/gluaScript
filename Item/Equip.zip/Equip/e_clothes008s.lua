ITEMINFO = {
	icon = 404,
	icon_f = 411,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "��Ես��",
	["required/level"] = 22,
	defense = 15,
	value = 2200,
	
}


