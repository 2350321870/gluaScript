ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "�ȷ���",
	["required/level"] = 60,
	["required/class"] = "xian",
	dresstype = "603",
	dresscolor = 1,
	max_damage = 61,
	no_bothhands = 1,
	value = 311200,
	
}


