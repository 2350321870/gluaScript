ITEMINFO = {
	list_icon = 59,
	type = "glove",
	wield_position = 7,
	is_bag_item = 1,
	name = "��Ӱ��+8��",
	--["required/level"] = 40,
	BindType = "Used_Bind",
	speed = 5,--�ٶ�
	riding = 3,--����
	value = 10038,
	max_hp=630,
	dex=37,
}
