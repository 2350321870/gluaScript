ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "�ݺ��׹",
	["required/level"] = 50,
	BindType = "ImmediatelyBind",
	dresstype = "703",
	dresscolor = 0,
	max_hp = 360,
	str=30,
	value = 40000,
	offer=700,  --������Ҫ�ﹱ
}


