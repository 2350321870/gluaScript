ITEMINFO = {
	icon = 406,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "�ݺ���",
	["required/level"] = 50,
	BindType = "ImmediatelyBind",
	dresstype = "703",
	dresscolor = 0,
	defense = 43,
	value = 40000,
	offer=400,  --������Ҫ�ﹱ
}


