ITEMINFO = {
	icon = 27,
	icon_f = 28,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "�߽ٹ�",
	["required/level"] = 40,
	--["required/gender"] = "����",
	max_mp = 215,
	defense = 24,
	value = 23456,
}


