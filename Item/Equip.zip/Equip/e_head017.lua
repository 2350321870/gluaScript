ITEMINFO = {
	icon = 33,
	icon_f = 34,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "��Թ��",
	["required/level"] = 49,
	--["required/gender"] = "����",
	max_mp = 260,
	defense = 33,
	value = 68888,
}


