ITEMINFO = {
	icon = 406,
	icon_f = 407,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "��ս��",
	["required/level"] = 30,
	["required/class"] = "shen",
	defense = 23,
	value = 8000,

}


