ITEMINFO = {
	icon = 1766,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "�����Ի�",
	["required/level"] = 98,
	["required/class"] = "xian",
	max_damage = 360,
	value = 390000,
}


