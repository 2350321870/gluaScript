ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "ϧ����׹",
	["required/level"] = 57,
	max_hp = 320,
	str=30,
	value = 15000,
}


