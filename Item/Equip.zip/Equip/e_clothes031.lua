ITEMINFO = {
	icon = 421,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "��ɷս��",
	["required/level"] = 91,
	defense = 125,
	value = 360000,
}


