ITEMINFO = {
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "@2������[+1]@0",
	["required/level"] = 65,
	max_hp = 333,
	str = 4,
	int = 4,
	value = 200,
}

