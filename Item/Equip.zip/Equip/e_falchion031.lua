ITEMINFO = {
	icon = 1531,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "��Х",
	["required/level"] = 94,
	["required/class"] = "shen",
	max_damage = 449,
	value = 360000,
}


