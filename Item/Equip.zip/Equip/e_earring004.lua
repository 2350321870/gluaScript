ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "��ѩ����",
	["required/level"] = 21,
	max_hp = 140,
	str=12,
	value = 600,
}


