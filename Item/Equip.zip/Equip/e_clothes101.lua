﻿ITEMINFO = {
	icon = 1,
	icon_f = 1,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "谋士新秀袍",
	["required/level"] = 10,
	["required/class"] = "xian",
	defense = 8,
	value = 300,
	
}


