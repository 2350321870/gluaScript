ITEMINFO = {
	icon = 1766,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "������",
	["required/level"] = 80,
	["required/class"] = "xian",
	dresstype = "803",
	dresscolor = 2,
	BindType = "Used_Bind",
	max_damage = 302,
	value = 999950,
}


