ITEMINFO = {
	icon = 1764,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "�ĺ���ˮ",
	["required/level"] = 86,
	["required/class"] = "xian",
	max_damage = 318,
	value = 300000,
}


