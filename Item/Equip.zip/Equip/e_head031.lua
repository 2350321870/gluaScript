ITEMINFO = {
	icon = 61,
	icon_f = 62,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "��ɷս��",
	["required/level"] = 91,
	--["required/gender"] = "����",
	max_mp = 470,
	defense = 93,
	value = 360000,
}


