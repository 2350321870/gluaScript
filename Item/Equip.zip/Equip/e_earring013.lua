ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "������׹",
	["required/level"] = 75,
	max_hp = 410,
	str=39,
	value = 80000,
}


