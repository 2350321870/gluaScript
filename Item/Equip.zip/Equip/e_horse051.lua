ITEMINFO = {
	list_icon = 59,
	type = "glove",
	wield_position = 7,
	is_bag_item = 1,
	name = "�ϵ硾+1��",
	--["required/level"] = 60,
	BindType = "Used_Bind",
	speed = 2,--�ٶ�
	riding = 5,--����
	value = 10051,
	max_hp=14,
	int=1,
}
