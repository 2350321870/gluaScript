ITEMINFO = {
	icon = 400,
	icon_f = 416,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "�ٱ���",
	["required/level"] =58,
	defense = 65,
	value = 300000,
}


