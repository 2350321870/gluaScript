ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "@2������[+8]@0",
	["required/level"] = 65,
	max_damage = 8,
	defense = 21,
	max_mp = 380,
	max_hp = 100,
	str = 10,
	value = 200,
}

