ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "ʥ������",
	["required/level"] = 70,
	["required/class"] = "xian",
	BindType = "ImmediatelyBind",
	dresstype = "705",
	dresscolor = 0,
	max_damage = 90,
	no_bothhands = 1,
	value = 48000,
	offer=1100,  --������Ҫ�ﹱ
}


