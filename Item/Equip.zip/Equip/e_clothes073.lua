ITEMINFO = {
	icon = 426,
	icon_f = 430,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "��������װ",
	BindType = "ImmediatelyBind",
	--["required/level"] = 10,
	--defense = 10,
	value = 1000,

}
