ITEMINFO = {
	icon = 1518,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "ʥ�鱦��",
	["required/level"] = 70,
	["required/class"] = "shen",
	BindType = "ImmediatelyBind",
	dresstype = "705",
	dresscolor = 0,
	max_damage = 418,
	value = 48000,
	offer=900,  --������Ҫ�ﹱ
}


