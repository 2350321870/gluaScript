ITEMINFO = {
	icon = 1512,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "������Ȫ",
	["required/level"] = 41,
	["required/class"] = "shen",
	max_damage = 199,
	value = 11000,
}


