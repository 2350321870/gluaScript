ITEMINFO = {
	list_icon = 59,
	type = "glove",
	wield_position = 7,
	is_bag_item = 1,
	name = "��Ӱ��+6��",
	--["required/level"] = 40,
	BindType = "Used_Bind",
	speed = 4,--�ٶ�
	riding = 3,--����
	value = 10036,
	max_hp=250,
	dex=14,
}
