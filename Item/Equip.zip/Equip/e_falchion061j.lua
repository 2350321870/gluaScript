ITEMINFO = {
	icon = 1514,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "��Ѫ",
	["required/level"] = 42,
	["required/class"] = "shen",
	BindType = "ImmediatelyBind",
	max_damage = 300,
	value = 23456,
}