ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "����ʼ��",
	["required/level"] = 24,
	useful_time_use=604800,
	["required/class"] = "xian",
	max_damage = 24,
	no_bothhands = 1,
	value = 600,

}


