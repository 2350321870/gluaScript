ITEMINFO = {
	--icon = 98,--13,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "��ͷ��",
	["required/level"] = 18,
	--["required/gender"] = "����",
	max_mp = 110,
	value = 1288,
}


