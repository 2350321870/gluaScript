ITEMINFO = {
	icon = 29,
	icon_f = 30,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "���˿��",
	["required/level"] = 43,
	--["required/gender"] = "����",
	max_mp = 230,
	defense = 27,
	value = 33888,
}


