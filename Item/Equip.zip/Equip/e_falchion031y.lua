ITEMINFO = {
	icon = 1531,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "��ħ��",
	["required/level"] = 91,
	["required/class"] = "shen",
	max_damage = 449,
	value = 4000000,
}


