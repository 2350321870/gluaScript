ITEMINFO = {
	icon = 51,
	icon_f = 52,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "��ħ�� ",
	["required/level"] = 76,
	--["required/gender"] = "����",
	max_mp = 395,
	defense = 68,
	value = 267777,
}


