ITEMINFO = {
	icon = 24,
	icon_f = 24,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "��ͷ",
	["required/level"] = 30,
	BindType = "ImmediatelyBind",
	--["required/gender"] = "����",
	dresstype = "30",
	dresscolor = 0,
	max_mp = 170,
	defense = 17,
	value = 9700,
}


