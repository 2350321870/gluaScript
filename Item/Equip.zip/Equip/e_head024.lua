ITEMINFO = {
	icon = 47,
	icon_f = 48,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "���տ�",
	["required/level"] = 70,
	--["required/gender"] = "����",
	max_mp = 365,
	defense = 59,
	value = 233333,
}


