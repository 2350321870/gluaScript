ITEMINFO = {
	icon = 424,
	icon_f = 428,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "������",
	BindType = "ImmediatelyBind",
	useful_time_get=604800,
	value = 200,
	--description = "",
}
