ITEMINFO = {
	icon = 63,
	icon_f = 64,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "������",
	["required/level"] = 80,
	--["required/gender"] = "����",
	BindType = "Used_Bind",
	dresstype = "803",
	dresscolor = 2,
	max_mp = 420,
	defense = 75,
	value = 1170000,
}


