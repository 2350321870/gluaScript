ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "��ɷ��׹",
	["required/level"] = 60,
	BindType = "Used_Bind",
	dresstype = "601",
	dresscolor = 0,
	max_hp = 450,
	str=41,
	value = 290600,
}


