ITEMINFO = {
	icon = 418,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "������",
	["required/level"] = 70,
	dresstype = "701",
	dresscolor = 1,
	defense = 81,
	value = 680030,

}


