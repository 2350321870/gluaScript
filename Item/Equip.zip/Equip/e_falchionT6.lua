ITEMINFO = {
	icon = 1532,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "����������",
	["required/level"] = 30,
--	BindType = "ImmediatelyBind",
    ["required/class"] = "shen",
	max_damage = 477,
	defense = 10,
	max_hp = 13,
	max_mp = 7,
	str = 41,
	dex = 22,
	int = 6,
	useful_time_get = 10800,
	pkdrop = 1,
	value = 2000,
}


