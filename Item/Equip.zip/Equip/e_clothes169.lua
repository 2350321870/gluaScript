ITEMINFO = {
	icon = 406,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "ʥ������",
	["required/level"] = 70,
	BindType = "ImmediatelyBind",
	dresstype = "705",
	dresscolor = 0,
	defense = 52,
	value = 48000,
	offer=400,  --������Ҫ�ﹱ
}


