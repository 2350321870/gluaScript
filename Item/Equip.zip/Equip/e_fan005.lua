ITEMINFO = {
	icon = 1755,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "��ң��",
	["required/level"] = 32,
	["required/class"] = "xian",
	max_damage = 129,
	value = 4888,
}


