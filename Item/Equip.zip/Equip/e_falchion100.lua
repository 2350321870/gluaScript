ITEMINFO = {
	icon = 1501,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "ˮ����",
	required_level = 9,
	required_class = "Warrior",
	max_duration = 200,
	max_damage = 8,
	value = 100,
}


