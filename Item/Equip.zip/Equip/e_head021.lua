ITEMINFO = {
	icon = 41,
	icon_f = 42,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "���ƿ�",
	["required/level"] = 61,
	--["required/gender"] = "����",
	max_mp = 320,
	defense = 47,
	value = 166666,
}


