ITEMINFO = {
	icon = 1526,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "����ն",
	["required/level"] = 82,
	["required/class"] = "shen",
	max_damage = 383,
	value = 267777,
}


