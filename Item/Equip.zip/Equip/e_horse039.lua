ITEMINFO = {
	list_icon = 59,
	type = "glove",
	wield_position = 7,
	is_bag_item = 1,
	name = "��Ӱ��+9��",
	--["required/level"] = 40,
	BindType = "Used_Bind",
	speed = 6,--�ٶ�
	riding = 3,--����
	value = 10039,
	max_hp=1000,
	dex=53,
}
