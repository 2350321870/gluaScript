ITEMINFO = {
	icon = 1526,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "���˵�",
	["required/level"] = 50,
	["required/class"] = "shen",
	BindType = "Used_Bind",
	dresstype = "501",
	dresscolor = 0,
	max_damage = 261,
	value = 33888,
}


