ITEMINFO = {
	icon = 399,
	icon_f = 421,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "ս��ʴ����",
	["required/level"] = 90,
	defense = 125,
	value = 1800000,
}


