ITEMINFO = {
	--icon = 9,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "��ս��",
	["required/level"] = 20,
	--["required/gender"] = "����",
	["required/class"] = "shen",
	max_mp = 115,
	value = 1500,
}


