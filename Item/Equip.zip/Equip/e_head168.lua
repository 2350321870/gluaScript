ITEMINFO = {
	icon = 31,
	icon_f = 32,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "��ӵ��",
	["required/level"] = 60,
	--["required/gender"] = "����",
	BindType = "ImmediatelyBind",
	dresstype = "704",
	dresscolor = 0,
	max_mp = 411,
	defense = 33.88,
	value = 45000,
	offer=300,  --������Ҫ�ﹱ
}


