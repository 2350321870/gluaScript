ITEMINFO = {
	icon = 31,
	icon_f = 32,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "�ݺ��",
	["required/level"] = 50,
	--["required/gender"] = "����",
	BindType = "ImmediatelyBind",
	dresstype = "703",
	dresscolor = 0,
	max_mp = 285,
	defense = 31,
	value = 40000,
	offer=300,  --������Ҫ�ﹱ
}


