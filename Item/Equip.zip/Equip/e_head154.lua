ITEMINFO = {
	icon = 45,
	icon_f = 46,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "��ɷ��",
	["required/level"] = 60,
	--["required/gender"] = "����",
	BindType = "Used_Bind",
	dresstype = "601",
	dresscolor = 1,
	max_mp = 420,
	defense = 57,
	value = 370000,
}


