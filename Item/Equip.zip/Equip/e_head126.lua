ITEMINFO = {
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "@2������[+5]@0",
	["required/level"] = 65,
	max_mp = 30,
	max_hp = 345,
	str = 8,
	dex = 7,
	int = 8,
	value = 200,
}

