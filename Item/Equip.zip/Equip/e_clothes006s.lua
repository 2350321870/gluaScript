ITEMINFO = {
	icon = 392,
	icon_f = 408,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "��Ե����",
	["required/level"] = 16,
	defense = 12,
	value = 740,

}


