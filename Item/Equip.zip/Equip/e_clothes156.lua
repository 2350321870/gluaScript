ITEMINFO = {
	icon = 413,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "�ȷ���",
	["required/level"] = 60,
	dresstype = "603",
	dresscolor = 1,
	defense = 70,
	value = 322230,

}


