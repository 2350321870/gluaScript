ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "��ս��",
	["required/level"] = 50,
	["required/class"] = "xian",
	BindType = "ImmediatelyBind",
	dresstype = "502",
	dresscolor = 0,
	max_damage = 52,
	no_bothhands = 1,
	value = 122200,
	offer=2500,  --������Ҫ�ﹱ
}


