ITEMINFO = {
	icon = 1516,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "�ϻ굶[��]",
	["required/level"] = 62,
	["required/class"] = "shen",
	max_damage = 310,
	["required/mp"] = 90,
	value = 100,
}

