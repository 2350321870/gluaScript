ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "ʥ���׹",
	["required/level"] = 70,
	BindType = "ImmediatelyBind",
	dresstype = "705",
	dresscolor = 0,
	max_hp = 300,
	str=43,
	value = 48000,
	offer=700,  --������Ҫ�ﹱ
}


