ITEMINFO = {
	icon = 1507,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "���굶",
	useful_time_use=604800,
	["required/level"] = 26,
	["required/class"] = "shen",
	max_damage = 133,
	value = 1400,
}


