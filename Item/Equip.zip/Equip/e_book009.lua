ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "��� ",
	["required/level"] = 57,
	["required/class"] = "xian",
	max_damage = 52,
	no_bothhands = 1,
	value = 15000,

}


