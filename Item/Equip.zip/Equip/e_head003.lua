ITEMINFO = {
	icon = 5,
	icon_f = 6,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "����ñ",
	["required/level"] = 7,
	--["required/gender"] = "����",
	max_mp = 50,
	defense = 5,
	value = 200,
}


