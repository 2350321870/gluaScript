ITEMINFO = {
	icon = 17,
	icon_f = 18,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "���Ŀ�",
	["required/level"] = 25,
	--["required/gender"] = "����",
	max_mp = 140,
	defense = 13,
	value = 3300,
}


