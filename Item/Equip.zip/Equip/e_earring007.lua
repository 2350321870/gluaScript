ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "�ɻ���׹",
	["required/level"] = 39,
	max_hp = 230,
	str=21,
	value = 3500,
}


