ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "�������",
	["required/level"] = 15,
	max_hp = 110,
	str=9,
	value = 350,
}


