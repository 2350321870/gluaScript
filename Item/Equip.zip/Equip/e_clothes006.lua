ITEMINFO = {
	icon = 396,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "�޳���",
	["required/level"] = 16,
	defense = 12,
	value = 740,

}


