ITEMINFO = {
	icon = 59,
	icon_f = 60,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "а��ս��",
	["required/level"] = 88,
	--["required/gender"] = "����",
	max_mp = 455,
	defense = 88,
	value = 344444,
}


