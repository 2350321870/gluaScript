ITEMINFO = {
	icon = 1506,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "@2������[+7]@0",
	["required/level"] = 65,
	["required/class"] = "shen",
	max_damage = 354,
	defense = 10,
	max_mp = 30,
	max_hp = 50,
	str = 10,
	value = 200,
}

