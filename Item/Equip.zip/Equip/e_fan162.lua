ITEMINFO = {
	icon = 1766,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "��ʥ��",
	["required/level"] = 80,
	["required/class"] = "xian",
	dresstype = "802",
	dresscolor = 2,
	max_damage = 25,
	value = 99990,
}


