ITEMINFO = {
	--icon = 29,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "ıʿ�����",
	["required/level"] = 10,
	--["required/gender"] = "����",
	["required/class"] = "xian",
	max_mp = 65,
	value = 300,
}


