ITEMINFO = {
	icon = 1532,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "������",
	["required/level"] = 80,
	["required/class"] = "shen",
	BindType = "Used_Bind",
	dresstype = "803",
	dresscolor = 2,
	max_damage = 375,
	value = 838888,
}


