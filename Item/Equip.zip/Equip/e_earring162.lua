ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "��ʥ����",
	["required/level"] = 80,
	dresstype = "802",
	dresscolor = 2,
	max_hp = 50,
	value = 600,
}


