ITEMINFO = {
	icon = 1759,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "��¶��",
	["required/level"] = 56,
	["required/class"] = "xian",
	max_damage = 213,
	value = 99999,
}


