ITEMINFO = {
	icon = 399,
	icon_f = 315,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "@2����ս��[+7]@0",
	["required/level"] = 65,
	defense = 87,
	max_mp = 85,
	max_hp = 82,
	str = 8,
	int = 7,
	value = 200,
}

