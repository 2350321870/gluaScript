ITEMINFO = {
	icon = 1756,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "������",
	["required/level"] = 38,
	["required/class"] = "xian",
	max_damage = 150,
	value = 11000,
}


