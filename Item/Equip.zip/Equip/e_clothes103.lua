﻿ITEMINFO = {
	icon = 0,
	icon_f = 0,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "战士新秀甲",
	["required/level"] = 10,
	["required/class"] = "shen",
	defense = 8,
	value = 300,
	
}


