ITEMINFO = {
	list_icon = 59,
	type = "glove",
	wield_position = 7,
	is_bag_item = 1,
	name = "���ס�+7��",
	--["required/level"] = 50,
	BindType = "Used_Bind",
	speed = 5,--�ٶ�
	riding = 4,--����
	value = 10047,
	max_hp=380,
	str=21,
}
