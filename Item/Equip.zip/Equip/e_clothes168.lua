ITEMINFO = {
	icon = 406,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "��ӵ��",
	["required/level"] = 60,
	BindType = "ImmediatelyBind",
	dresstype = "704",
	dresscolor = 0,
	defense = 47,
	value = 45000,
	offer=400,  --������Ҫ�ﹱ
}


