ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "@2������[+7]@0",
	["required/level"] = 65,
	max_damage = 7,
	defense = 19,
	max_mp = 370,
	max_hp = 90,
	str = 9,
	value = 200,
}

