ITEMINFO = {
	icon = 1,
	icon_f = 2,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "������",
	["required/level"] = 1,
	--["required/gender"] = "����",
	max_mp = 20,
	defense = 3,
	value = 50,
}


