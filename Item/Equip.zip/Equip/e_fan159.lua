ITEMINFO = {
	icon = 1764,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "������",
	["required/level"] = 70,
	["required/class"] = "xian",
	dresstype = "702",
	dresscolor = 1,
	BindType = "Used_Bind",
	max_damage = 255,
	value = 300050,
}

