ITEMINFO = {
	icon = 57,
	icon_f = 58,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "�̻��",
	["required/level"] = 85,
	--["required/gender"] = "����",
	max_mp = 440,
	defense = 83,
	value = 322222,
}


