ITEMINFO = {
	icon = 55,
	icon_f = 56,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "������",
	["required/level"] = 82,
	--["required/gender"] = "����",
	max_mp = 425,
	defense = 78,
	value = 300000,
}


