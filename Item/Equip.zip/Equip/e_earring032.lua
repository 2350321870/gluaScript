ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "��ħ����",
	["required/level"] = 60,
	BindType = "Used_Bind",
	dresstype = "802",
	dresscolor = 2,
	max_hp = 3000,
	str=240,
	value = 100,
}


