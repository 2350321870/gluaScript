ITEMINFO = {
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "������[��]",
	["required/level"] = 62,
	["required/mp"] = 49,
	["apply/hp"] = 355,
	value = 100,
}

