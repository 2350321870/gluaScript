ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "ǿ����",
	["required/level"] = 40,
	["required/class"] = "xian",
	BindType = "ImmediatelyBind",
	dresstype = "40",
	dresscolor = 0,
	max_damage = 47,
	no_bothhands = 1,
	value = 44200,
	offer=1100,  --������Ҫ�ﹱ
}


