ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "@2������[+2]@0",
	["required/level"] = 65,
	defense = 9,
	max_mp = 320,
	max_hp = 40,
	str = 4,
	value = 200,
}

