ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "@2������[+1]@0",
	["required/level"] = 65,
	defense = 7,
	max_mp = 310,
	max_hp = 30,
	value = 200,
}

