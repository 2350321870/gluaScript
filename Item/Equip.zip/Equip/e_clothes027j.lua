ITEMINFO = {
	icon = 401,
	icon_f = 417,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "������",
	["required/level"] = 78,
	defense = 97,
	value = 1000000,
}


