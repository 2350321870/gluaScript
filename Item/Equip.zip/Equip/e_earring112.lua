ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "���׹[��]",
	["required/level"] = 62,
	defense = 12,
	["required/mp"] = 300,
	value = 100,
}

