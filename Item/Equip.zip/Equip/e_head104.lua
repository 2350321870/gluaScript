ITEMINFO = {
	--icon = 5,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "Զı��",
	["required/level"] = 20,
	--["required/gender"] = "����",
	["required/class"] = "xian",
	max_mp = 115,
	value = 1500,
}


