ITEMINFO = {
	icon = 399,
	icon_f = 315,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "@2神武战袍[+5]@0",
	["required/level"] = 65,
	defense = 83,
	max_mp = 65,
	max_hp = 62,
	str = 6,
	int = 5,
	value = 9750,
}


