ITEMINFO = {
	icon = 13,
	icon_f = 14,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "通天冠",
	["required/level"] = 19,
	--["required/gender"] = "男性",
	max_mp = 110,
	defense = 9,
	value = 2850,
}


