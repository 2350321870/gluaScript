ITEMINFO = {
	icon = 406,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "强者袍",
	["required/level"] = 40,
	BindType = "ImmediatelyBind",
	dresstype = "40",
	dresscolor = 0,
	defense = 39,
	value = 6000,
	offer=400,  --购买需要帮贡
}


