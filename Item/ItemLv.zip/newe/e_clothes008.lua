ITEMINFO = {
	icon = 398,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "血幽甲",
	["required/level"] = 22,
	defense = 15,
	value = 3300,
	
}


