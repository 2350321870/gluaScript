ITEMINFO = {
	icon = 1527,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "破风刀",
	["required/level"] = 81,
	["required/class"] = "shen",
	max_damage = 397,
	value = 12150,
}


