ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "凤凰坠[煌]",
	["required/level"] = 62,
	["required/mp"] = 350,
	int = 9,
	value = 9300,
}


