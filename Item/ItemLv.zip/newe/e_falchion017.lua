ITEMINFO = {
	icon = 1517,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "寸斩",
	["required/level"] = 56,
	["required/class"] = "shen",
	max_damage = 265,
	value = 8400,
}


