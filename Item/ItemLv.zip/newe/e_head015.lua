ITEMINFO = {
	icon = 29,
	icon_f = 30,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "天蚕丝冠",
	["required/level"] = 43,
	--["required/gender"] = "男性",
	max_mp = 230,
	defense = 27,
	value = 6450,
}


