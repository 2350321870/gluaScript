ITEMINFO = {
	icon = 414,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "炎日甲 ",
	["required/level"] = 70,
	defense = 80,
	value = 10500,
}


