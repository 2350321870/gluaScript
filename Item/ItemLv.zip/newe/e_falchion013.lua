ITEMINFO = {
	icon = 1513,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "新月",
	["required/level"] = 44,
	["required/class"] = "shen",
	max_damage = 212,
	value = 6600,
}


