ITEMINFO = {
	--icon = 98,--37,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "玄铁盔",
	["required/level"] = 54,
	--["required/gender"] = "男性",
	max_mp = 290,
	value = 8100,
}


