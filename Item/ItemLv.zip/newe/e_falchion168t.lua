ITEMINFO = {
	icon = 1518,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "风拥刀",
	["required/level"] = 60,
	["required/class"] = "shen",
	BindType = "ImmediatelyBind",
        useful_time_get=7200,
	dresstype = "704",
	dresscolor = 0,
	max_damage = 348,
	value = 9000,
	offer=900,  --购买需要帮贡
}


