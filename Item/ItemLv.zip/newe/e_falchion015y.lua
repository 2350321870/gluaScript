ITEMINFO = {
	icon = 1515,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "开山刀",
	["required/level"] = 47,
	["required/class"] = "shen",
	max_damage = 238,
	value = 7050,
}


