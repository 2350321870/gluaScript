ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "@2虹光耳环[+5]@0",
	["required/level"] = 65,
	max_damage = 5,
	defense = 15,
	max_mp = 350,
	max_hp = 70,
	str = 7,
	value = 9750,
}


