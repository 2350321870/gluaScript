ITEMINFO = {
	icon = 1514,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "傲血",
	["required/level"] = 42,
	["required/class"] = "shen",
	BindType = "ImmediatelyBind",
	max_damage = 440,
	value = 6300,
}


