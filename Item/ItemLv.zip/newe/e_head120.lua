ITEMINFO = {
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "青阳盔[煌]",
	["required/level"] = 62,
	["apply/hp"] = 355,
	int = 12,
	value = 9300,
}


