ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "善战书",
	["required/level"] = 50,
	["required/class"] = "xian",
	BindType = "ImmediatelyBind",
	dresstype = "502",
	dresscolor = 0,
	max_damage = 52,
	no_bothhands = 1,
	value = 7500,
	offer=2500,  --购买需要帮贡
}


