ITEMINFO = {
	icon = 45,
	icon_f = 46,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "先锋冠",
	["required/level"] = 60,
	--["required/gender"] = "男性",
	dresstype = "603",
	dresscolor = 1,
	max_mp = 400,
	defense = 52,
	value = 9000,
}


