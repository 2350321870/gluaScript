ITEMINFO = {
	icon = 7,
	icon_f = 8,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "金缕帽",
	["required/level"] = 10,
	--["required/gender"] = "男性",
	max_mp = 65,
	defense = 6,
	value = 1500,
}


