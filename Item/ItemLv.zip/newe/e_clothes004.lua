ITEMINFO = {
	icon = 394,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "金缕衣",
	["required/level"] = 10,
	defense = 8,
	value = 1500,
	
}


