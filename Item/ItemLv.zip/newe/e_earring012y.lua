ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "探测耳环",
	["required/level"] = 75,
	max_hp = 380,
	value = 11250,
}


