ITEMINFO = {
	icon = 23,
	icon_f = 24,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "幸运冠",
	["required/level"] = 50,
	--["required/gender"] = "男性",
	BindType = "Used_Bind",
	dresstype = "501",
	dresscolor = 0,
	max_mp = 355,
	defense = 42,
	value = 7500,
}


