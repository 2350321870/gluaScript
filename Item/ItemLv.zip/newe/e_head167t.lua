ITEMINFO = {
	icon = 31,
	icon_f = 32,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "纵横冠",
	["required/level"] = 50,
	--["required/gender"] = "男性",
	BindType = "ImmediatelyBind",
        useful_time_get=7200,
	dresstype = "703",
	dresscolor = 0,
	max_mp = 285,
	defense = 31,
	value = 7500,
	offer=300,  --购买需要帮贡
}


