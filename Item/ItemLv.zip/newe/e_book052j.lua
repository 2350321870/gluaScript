ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "天篆",
	["required/level"] = 72,
	["required/class"] = "xian",
	BindType = "ImmediatelyBind",
	max_damage = 140,
	no_bothhands = 1,
	value = 10800,

}


