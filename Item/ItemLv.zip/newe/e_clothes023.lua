ITEMINFO = {
	icon = 413,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "苍月甲",
	["required/level"] = 67,
	defense = 75,
	value = 10050,
}


