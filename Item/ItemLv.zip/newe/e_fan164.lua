ITEMINFO = {
	icon = 1766,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "啸天扇",
	["required/level"] = 80,
	["required/class"] = "xian",
	BindType = "Used_Bind",
	dresstype = "804",
	dresscolor = 2,
	max_damage = 302,
	value = 12000,
}


