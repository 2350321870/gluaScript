ITEMINFO = {
	icon = 399,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "焚心甲",
	["required/level"] = 25,
	defense = 16,
	value = 3750,
	
}


