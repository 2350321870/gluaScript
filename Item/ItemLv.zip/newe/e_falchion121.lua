ITEMINFO = {
	icon = 1506,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "@2御龙刀[+0]@0",
	["required/level"] = 65,
	["required/class"] = "shen",
	max_damage = 340,
	max_hp = 15,
	str = 3,
	value = 9750,
}


