ITEMINFO = {
	icon = 1754,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "竹丝扇",
	["required/level"] = 26,
	["required/class"] = "xian",
	max_damage = 108,
	value = 3900,
}


