ITEMINFO = {
	list_icon = 59,--------道具图标
	type = "glove",---------类型
	wield_position = 7,--------装备位
	is_bag_item = 1,--------普通背包
	name = "云海【+6】",--
	--["required/level"] = 20,
	BindType = "Used_Bind",---------绑定
	speed = 4,--速度
	riding = 1,--类型
	value = 3000,
	max_hp=250,
	defense=15,
}
