ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "悯夏耳坠",
	["required/level"] = 63,
	max_hp = 350,
	str=33,
	value = 9450,
}


