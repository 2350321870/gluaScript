ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "怜秋耳坠",
	["required/level"] = 69,
	max_hp = 380,
	str=36,
	value = 10350,
}


