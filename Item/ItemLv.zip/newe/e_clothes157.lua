ITEMINFO = {
	icon = 413,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "侠客袍",
	["required/level"] = 60,
	BindType = "Used_Bind",
	dresstype = "604",
	dresscolor = 1,
	defense = 70,
	value = 9000,

}


