ITEMINFO = {
	icon = 1524,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "虎齿",
	["required/level"] = 77,
	["required/class"] = "shen",
	max_damage = 357,
	value = 11550,
}


