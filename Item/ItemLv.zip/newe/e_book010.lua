ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "春秋",
	["required/level"] = 63,
	["required/class"] = "xian",
	max_damage = 57,
	no_bothhands = 1,
	value = 9450,
	
}


