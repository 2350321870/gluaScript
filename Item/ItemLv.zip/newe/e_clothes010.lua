ITEMINFO = {
	icon = 400,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "花雨衫",
	["required/level"] = 28,
	defense = 20,
	value = 4200,

}


