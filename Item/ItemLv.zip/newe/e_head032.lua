ITEMINFO = {
	icon = 17,
	icon_f = 18,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "天魔战盔",
	["required/level"] = 60,
	--["required/gender"] = "男性",
	max_mp = 2425,
	defense = 490,
	value = 9000,
}


