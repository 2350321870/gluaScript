ITEMINFO = {
	--icon = 29,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "谋士新秀冠",
	["required/level"] = 10,
	--["required/gender"] = "男性",
	["required/class"] = "xian",
	max_mp = 65,
	value = 1500,
}


