ITEMINFO = {
	list_icon = 59,
	type = "glove",
	wield_position = 7,
	is_bag_item = 1,
	name = "训练用马",--1
	--["required/level"] = 20,
	BindType = "ImmediatelyBind",
	speed = 1,--速度
	riding = 3,--类型
	value = 3000,
}
