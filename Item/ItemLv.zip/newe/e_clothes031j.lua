ITEMINFO = {
	icon = 399,
	icon_f = 421,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "战神蚀日铠",
	["required/level"] = 90,
	defense = 125,
	value = 13500,
}


