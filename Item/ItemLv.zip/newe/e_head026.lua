ITEMINFO = {
	icon = 51,
	icon_f = 52,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "葬魔冠 ",
	["required/level"] = 76,
	--["required/gender"] = "男性",
	max_mp = 395,
	defense = 68,
	value = 11400,
}


