ITEMINFO = {
	icon = 1752,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "白骨扇",
	["required/level"] = 14,
	["required/class"] = "xian",
	max_damage = 66,
	value = 2100,
}


