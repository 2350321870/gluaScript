ITEMINFO = {
	icon = 406,
	icon_f = 415,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "锦天",
	["required/level"] = 12,
	BindType = "Used_Bind",
	defense = 48,
	value = 1800,

}


