ITEMINFO = {
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "青阳盔[辉]",
	["required/level"] = 62,
	["required/mp"] = 60,
	["apply/hp"] = 330,
	value = 9300,
}


