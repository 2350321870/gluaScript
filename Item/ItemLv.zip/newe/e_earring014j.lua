ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "诸侯耳环",
	["required/level"] = 92,
	max_hp = 440,
	value = 13800,
}


