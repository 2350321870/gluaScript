ITEMINFO = {
	icon = 412,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "衍星甲",
	["required/level"] = 64,
	defense = 70,
	value = 9600,
}


