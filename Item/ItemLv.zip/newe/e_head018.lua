ITEMINFO = {
	icon = 35,
	icon_f = 36,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "血灵盔",
	["required/level"] = 52,
	--["required/gender"] = "男性",
	max_mp = 275,
	defense = 36,
	value = 7800,
}


