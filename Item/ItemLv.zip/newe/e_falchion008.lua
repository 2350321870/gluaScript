ITEMINFO = {
	icon = 1508,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "追风",
	["required/level"] = 29,
	["required/class"] = "shen",
	max_damage = 146,
	value = 4350,
}


