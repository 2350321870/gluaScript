ITEMINFO = {
	list_icon = 29,
	type = "book",
	wield_position = 2,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "@2武经[+2]@0",
	["required/level"] = 65,
	["required/class"] = "xian",
	max_damage = 60,
	defense = 5,
	max_mp = 21,
	int = 4,
	value = 9750,
}


