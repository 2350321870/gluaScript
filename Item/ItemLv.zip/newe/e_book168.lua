ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "风拥书",
	["required/level"] = 60,
	["required/class"] = "xian",
	BindType = "ImmediatelyBind",
	dresstype = "704",
	dresscolor = 0,
	max_damage = 75,
	no_bothhands = 1,
	value = 9000,
	offer=1100,  --购买需要帮贡
}


