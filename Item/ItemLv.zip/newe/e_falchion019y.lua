ITEMINFO = {
	icon = 1519,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "武曲刀",
	["required/level"] = 59,
	["required/class"] = "shen",
	max_damage = 291,
	value = 8850,
}


