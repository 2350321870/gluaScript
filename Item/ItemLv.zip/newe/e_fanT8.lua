ITEMINFO = {
	icon = 1766,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "天罡烈焰芭蕉扇",
	["required/level"] = 30,
--	BindType = "ImmediatelyBind",
    ["required/class"] = "xian",
	max_damage = 435,
	defense = 2,
	max_hp = 4,
	max_mp = 231,
	str = 12,
	dex = 21,
	int = 39,
	useful_time_get = 10800,
	pkdrop = 1,
	value = 4500,
}


