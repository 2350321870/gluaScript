ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "善战耳坠",
	["required/level"] = 50,
	BindType = "ImmediatelyBind",
	dresstype = "502",
	dresscolor = 0,
	max_hp = 410,
	str=33,
	value = 7500,
	offer=1800,  --购买需要帮贡
}


