ITEMINFO = {
	icon = 397,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "通天袍",
	["required/level"] = 19,
	defense = 14,
	value = 2850,

}


