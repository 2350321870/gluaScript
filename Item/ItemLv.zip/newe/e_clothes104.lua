ITEMINFO = {
	icon = 417,
	icon_f = 407,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "远谋袍",
	["required/level"] = 20,
	["required/class"] = "xian",
	defense = 15,
	value = 3000,

}


