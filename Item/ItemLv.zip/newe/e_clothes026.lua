ITEMINFO = {
	icon = 416,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "葬魔袍",
	["required/level"] = 76,
	defense = 90,
	value = 11400,
}


