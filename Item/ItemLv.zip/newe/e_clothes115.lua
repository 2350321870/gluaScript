ITEMINFO = {
	icon = 393,
	icon_f = 409,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "虎王铠[羽]",
	["required/level"] = 62,
	defense = 73,
	dex = 8,
	value = 9300,
}


