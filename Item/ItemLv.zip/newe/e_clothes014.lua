ITEMINFO = {
	icon = 404,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "七劫袍",
	["required/level"] = 40,
	defense = 35,
	value = 6000,

}


