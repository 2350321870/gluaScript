ITEMINFO = {
	list_icon = 29,
	type = "book",
	wield_position = 2,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "@2武经[+0]@0",
	["required/level"] = 65,
	["required/class"] = "xian",
	max_damage = 58,
	max_mp = 5,
	int = 2,
	value = 9750,
}


