ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "纵横书",
	["required/level"] = 50,
	["required/class"] = "xian",
	BindType = "ImmediatelyBind",
	dresstype = "703",
	dresscolor = 0,
	max_damage = 63,
	no_bothhands = 1,
	value = 7500,
}


