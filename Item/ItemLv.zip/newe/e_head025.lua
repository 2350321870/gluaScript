ITEMINFO = {
	icon = 49,
	icon_f = 50,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "纹龙盔",
	["required/level"] = 73,
	--["required/gender"] = "男性",
	max_mp = 380,
	defense = 63,
	value = 10950,
}


