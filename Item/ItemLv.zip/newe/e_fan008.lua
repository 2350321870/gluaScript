ITEMINFO = {
	icon = 1758,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "衬月扇",
	["required/level"] = 50,
	["required/class"] = "xian",
	max_damage = 192,
	value = 7500,
}


