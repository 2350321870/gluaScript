ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "凤凰坠[刺]",
	["required/level"] = 62,
	max_damage = 8,
	["required/mp"] = 350,
	value = 9300,
}


