ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "中庸",
	["required/level"] = 27,
	["required/class"] = "xian",
	max_damage = 26,
	no_bothhands = 1,
	value = 4050,
	
}


