ITEMINFO = {
	icon = 11,
	icon_f = 12,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "无常冠",
	["required/level"] = 16,
	--["required/gender"] = "男性",
	max_mp = 95,
	defense = 8,
	value = 2400,
}


