ITEMINFO = {
	icon = 418,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "豪杰铠",
	["required/level"] = 70,
	BindType = "Used_Bind",
	dresstype = "703",
	dresscolor = 1,
	defense = 2,
	value = 10500,

}


