ITEMINFO = {
	icon = 397,
	icon_f = 413,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "纹龙朝服",
	["required/level"] = 18,
	defense = 14,
	value = 2700,

}


