ITEMINFO = {
	icon = 1518,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "圣灵宝刀",
	["required/level"] = 70,
	["required/class"] = "shen",
	BindType = "ImmediatelyBind",
        useful_time_get=7200,
	dresstype = "705",
	dresscolor = 0,
	max_damage = 418,
	value = 10500,
	offer=900,  --购买需要帮贡
}


