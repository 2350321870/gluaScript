ITEMINFO = {
	icon = 392,
	icon_f = 415,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "虎贲甲",
	["required/level"] = 46,
	defense = 44,
	value = 6900,

}


