ITEMINFO = {
	icon = 1506,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "@2御龙刀[+9]@0",
	["required/level"] = 65,
	["required/class"] = "shen",
	max_damage = 358,
	defense = 12,
	max_mp = 50,
	max_hp = 60,
	str = 12,
	value = 9750,
}


