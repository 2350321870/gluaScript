ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "霞飞耳坠",
	["required/level"] = 51,
	max_hp = 290,
	str=27,
	value = 7650,
}


