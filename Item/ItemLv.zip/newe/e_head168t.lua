ITEMINFO = {
	icon = 31,
	icon_f = 32,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "风拥冠",
	["required/level"] = 60,
	--["required/gender"] = "男性",
	BindType = "ImmediatelyBind",
        useful_time_get=7200,
	dresstype = "704",
	dresscolor = 0,
	max_mp = 411,
	defense = 33.88,
	value = 9000,
	offer=300,  --购买需要帮贡
}


