ITEMINFO = {
	icon = 1764,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "勇者扇",
	["required/level"] = 70,
	["required/class"] = "xian",
	dresstype = "701",
	dresscolor = 1,
	max_damage = 266,
	value = 10500,
}


