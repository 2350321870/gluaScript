ITEMINFO = {
	icon = 1532,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "武圣刀",
	["required/level"] = 80,
	["required/class"] = "shen",
	dresstype = "802",
	dresscolor = 2,
	max_damage = 25,
	value = 12000,
}


