ITEMINFO = {
	icon = 395,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "化血甲",
	["required/level"] = 13,
	defense = 10,
	value = 1950,

}


