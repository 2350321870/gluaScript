ITEMINFO = {
	icon = 43,
	icon_f = 44,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "衍星盔",
	["required/level"] = 64,
	--["required/gender"] = "男性",
	max_mp = 335,
	defense = 51,
	value = 9600,
}


