ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "纵横耳坠",
	["required/level"] = 50,
	BindType = "ImmediatelyBind",
	dresstype = "703",
	dresscolor = 0,
	max_hp = 360,
	str=30,
	value = 7500,
	offer=700,  --购买需要帮贡
}


