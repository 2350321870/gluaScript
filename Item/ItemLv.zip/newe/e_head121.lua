ITEMINFO = {
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "@2紫阳冠[+0]@0",
	["required/level"] = 65,
	max_hp = 330,
	str = 3,
	int = 3,
	value = 9750,
}


