ITEMINFO = {
	icon = 397,
	icon_f = 413,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "红云镔铁衣",
	["required/level"] = 66,
	defense = 75,
	value = 9900,
}


