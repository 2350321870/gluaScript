ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "凤凰坠[羽]",
	["required/level"] = 62,
	["required/mp"] = 300,
	dex = 6,
	value = 9300,
}


