ITEMINFO = {
	icon = 406,
	icon_f = 415,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "太玄",
	["required/level"] = 72,
	BindType = "ImmediatelyBind",
	defense = 360,
	value = 10800,
}


