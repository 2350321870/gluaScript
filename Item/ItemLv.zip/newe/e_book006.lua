ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "孟子",
	["required/level"] = 39,
	["required/class"] = "xian",
	max_damage = 37,
	no_bothhands = 1,
	value = 5850,

}


