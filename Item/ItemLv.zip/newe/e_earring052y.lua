ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "沉星",
	["required/level"] = 72,
	BindType = "Used_Bind",
	max_hp = 1400,
	value = 10800,
}


