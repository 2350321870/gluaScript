ITEMINFO = {
	icon = 411,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "雷云甲",
	["required/level"] = 61,
	defense = 65,
	value = 9150,
}


