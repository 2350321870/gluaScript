ITEMINFO = {
	list_icon = 29,
	type = "book",
	wield_position = 2,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "冲虚经[坚]",
	["required/level"] = 62,
	["required/class"] = "xian",
	max_damage = 50,
	["apply/hp"] = 50,
	value = 9300,
}


