ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "听霜耳环",
	["required/level"] = 27,
	max_hp = 170,
	str=15,
	value = 4050,
}


