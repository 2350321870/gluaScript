ITEMINFO = {
	--icon = 23,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "颂战盔",
	["required/level"] = 30,
	--["required/gender"] = "男性",
	["required/class"] = "shen",
	max_mp = 160,
	value = 4500,
}


