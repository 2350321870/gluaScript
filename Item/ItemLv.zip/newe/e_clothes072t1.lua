ITEMINFO = {
	icon = 425,
	icon_f = 429,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "虎王甲",
	BindType = "ImmediatelyBind",
	useful_time_get=604800,
	value = 200,
	--description = "",
}
