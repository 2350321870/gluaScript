ITEMINFO = {
	icon = 1751,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "红羽扇",
	["required/level"] = 7,
	["required/class"] = "xian",
	max_damage = 41,
	value = 1050,
}


