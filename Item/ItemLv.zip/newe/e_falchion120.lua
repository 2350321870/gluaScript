ITEMINFO = {
	icon = 1516,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "断魂刀[坚]",
	["required/level"] = 62,
	["required/class"] = "shen",
	max_damage = 330,
	defense = 5,
	value = 9300,
}


