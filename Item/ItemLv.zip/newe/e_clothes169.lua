ITEMINFO = {
	icon = 406,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "圣灵仙袍",
	["required/level"] = 70,
	BindType = "ImmediatelyBind",
	dresstype = "705",
	dresscolor = 0,
	defense = 52,
	value = 10500,
	offer=400,  --购买需要帮贡
}


