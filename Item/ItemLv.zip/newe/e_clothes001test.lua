ITEMINFO = {
	icon = 399,
	icon_f = 413,--女性显示装束动画编号
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "@2粗布衣@0",
	["required/level"] = 1,
	max_damage = 234,
	defense = 200,
	max_hp=200,
	max_mp=200,
	str=100,
	def=100,
	int=100,
	value = 150,

}

镶嵌属性={


}

品阶属性={
add_max_damage = 234,
add_defense = 200,
add_max_hp=200,
add_max_mp=200,
add_str=100,
add_def=100,
add_int=100,

}

