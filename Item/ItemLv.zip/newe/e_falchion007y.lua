ITEMINFO = {
	icon = 1507,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "勾魂刀",
	["required/level"] = 23,
	["required/class"] = "shen",
	max_damage = 133,
	value = 3450,
}


