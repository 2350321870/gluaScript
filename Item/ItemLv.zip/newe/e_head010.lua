ITEMINFO = {
	icon = 19,
	icon_f = 20,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "花雨巾",
	["required/level"] = 28,
	--["required/gender"] = "男性",
	max_mp = 155,
	defense = 15,
	value = 4200,
}


