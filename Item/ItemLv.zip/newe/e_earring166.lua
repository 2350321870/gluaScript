ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "泛坠",
	["required/level"] = 30,
	BindType = "ImmediatelyBind",
	dresstype = "30",
	dresscolor = 0,
	max_hp = 200,
	str=18,
	value = 4500,
}


