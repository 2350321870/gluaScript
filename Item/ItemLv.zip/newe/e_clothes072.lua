ITEMINFO = {
	icon = 425,
	icon_f = 429,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "定国凯旋装",
	BindType = "ImmediatelyBind",
	--["required/level"] = 10,
	--defense = 10,
	value = 1500,

}
