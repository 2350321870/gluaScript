ITEMINFO = {
	icon = 1504,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "白炎",
	["required/level"] = 16,
	["required/class"] = "shen",
	max_damage = 87,
	value = 2400,
}


