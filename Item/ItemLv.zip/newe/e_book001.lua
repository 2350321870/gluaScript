ITEMINFO = {
	list_icon = 19,		--装备图标
	wield_position = 2,	--装备位置
	type = "book",		--装备类型
	is_bag_item = 1,	--背包位置
	name = "三国志",	--装备名称
	["required/level"] = 11,--所需等级
	["required/class"] = "xian",--职业限定
	max_damage = 12,	--最大攻击
	no_bothhands = 1,	--非双持武器，
	value = 1650,
			
}


