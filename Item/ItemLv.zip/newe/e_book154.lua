ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "七煞书",
	["required/level"] = 60,
	["required/class"] = "xian",
	BindType = "Used_Bind",
	dresstype = "601",
	dresscolor = 1,
	max_damage = 68,
	no_bothhands = 1,
	value = 9000,
	
}


