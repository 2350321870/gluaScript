ITEMINFO = {
	icon = 1507,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "天师邪刀",
	["required/level"] = 25,
	["required/class"] = "shen",
	max_damage = 133,
	value = 3750,
}
