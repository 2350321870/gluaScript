ITEMINFO = {
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "@2紫阳冠[+7]@0",
	["required/level"] = 65,
	max_mp = 50,
	max_hp = 351,
	str = 10,
	dex = 9,
	int = 10,
	value = 9750,
}


