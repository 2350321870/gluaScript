ITEMINFO = {
	icon = 423,
	icon_f = 427,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "赤霞银狐裘",
	BindType = "ImmediatelyBind",
	--["required/level"] = 10,
	--defense = 10,
	value = 1500,

}
