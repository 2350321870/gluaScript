ITEMINFO = {
	list_icon = 29,
	type = "book",
	wield_position = 2,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "@2武经[+5]@0",
	["required/level"] = 65,
	["required/class"] = "xian",
	max_damage = 63,
	defense = 8,
	max_mp = 45,
	max_hp = 22,
	int = 7,
	value = 9750,
}


