ITEMINFO = {
	icon = 410,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "玄火袍",
	["required/level"] = 58,
	defense = 60,
	value = 8700,
}


