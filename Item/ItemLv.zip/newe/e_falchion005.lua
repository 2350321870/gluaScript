ITEMINFO = {
	icon = 1505,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "破浪",
	["required/level"] = 20,
	["required/class"] = "shen",
	max_damage = 106,
	value = 3000,
}


