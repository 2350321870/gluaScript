ITEMINFO = {
	icon = 1528,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "七煞斩",
	["required/level"] = 60,
	["required/class"] = "shen",
	BindType = "Used_Bind",
	dresstype = "601",
	dresscolor = 1,
	max_damage = 321,
	value = 9000,
}


