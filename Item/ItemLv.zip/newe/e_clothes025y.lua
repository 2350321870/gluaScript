ITEMINFO = {
	icon = 399,
	icon_f = 415,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "云中锦袍",
	["required/level"] = 70,
	defense = 85,
	value = 10500,
}


