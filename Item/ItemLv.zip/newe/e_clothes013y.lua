ITEMINFO = {
	icon = 402,
	icon_f = 422,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "君王铠甲",
	["required/level"] = 34,
	defense = 32,
	value = 5100,

}


