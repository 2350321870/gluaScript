ITEMINFO = {
	icon = 408,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "血灵甲",
	["required/level"] = 52,
	defense = 49,
	value = 7800,
}


