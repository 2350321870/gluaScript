ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "@2虹光耳环[+0]@0",
	["required/level"] = 65,
	defense = 5,
	max_mp = 300,
	max_hp = 20,
	value = 9750,
}


