ITEMINFO = {
	icon = 31,
	icon_f = 32,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "厉咒盔",
	["required/level"] = 46,
	--["required/gender"] = "男性",
	max_mp = 245,
	defense = 30,
	value = 6900,
}


