ITEMINFO = {
	icon = 1531,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "三阴戮妖玄刀",
	["required/level"] = 30,
--	BindType = "ImmediatelyBind",
    ["required/class"] = "shen",
	max_damage = 450,
	defense = 18,
	max_hp = 221,
	max_mp = 19,
	str = 18,
	dex = 22,
	int = 17,
	useful_time_get = 10800,
	pkdrop = 1,
	value = 4500,
}


