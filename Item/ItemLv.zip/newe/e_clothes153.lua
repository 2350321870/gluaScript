ITEMINFO = {
	icon = 402,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "善战袍",
	["required/level"] = 50,
	BindType = "ImmediatelyBind",
	dresstype = "502",
	dresscolor = 0,
	defense = 59,
	value = 7500,
	offer=1200,  --购买需要帮贡
}


