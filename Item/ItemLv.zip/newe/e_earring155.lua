ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "沙场耳坠",
	["required/level"] = 60,
	BindType = "Used_Bind",
	dresstype = "602",
	dresscolor = 0,
	max_hp = 480,
	str=50,
	value = 9000,
}


