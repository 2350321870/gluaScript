ITEMINFO = {
	icon = 1503,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "鬼斩",
	["required/level"] =10,
	["required/class"] = "shen",
	max_damage = 61,
	value = 200,
}


