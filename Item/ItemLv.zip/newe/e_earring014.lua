ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "竹青耳坠",
	["required/level"] = 80,
	max_hp = 440,
	str=42,
	value = 12000,
}


