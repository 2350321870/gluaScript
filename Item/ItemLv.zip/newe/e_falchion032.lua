ITEMINFO = {
	icon = 1532,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "龙吟",
	["required/level"] = 98,
	["required/class"] = "shen",
	max_damage = 463,
	value = 14700,
}


