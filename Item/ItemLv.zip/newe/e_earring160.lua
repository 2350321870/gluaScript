ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "豪杰耳环",
	["required/level"] = 70,
	BindType = "Used_Bind",
	dresstype = "703",
	dresscolor = 0,
	max_hp = 50,
	value = 10500,
}


