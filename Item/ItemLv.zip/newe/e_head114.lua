ITEMINFO = {
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "青阳盔[羽]",
	["required/level"] = 62,
	["apply/hp"] = 330,
	dex = 10,
	value = 9300,
}


