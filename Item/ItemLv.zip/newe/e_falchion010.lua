ITEMINFO = {
	icon = 1510,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "夺神",
	["required/level"] = 35,
	["required/class"] = "shen",
	max_damage = 172,
	value = 5250,
}


