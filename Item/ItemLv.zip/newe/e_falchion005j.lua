ITEMINFO = {
	icon = 1505,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "雁翔刀",
	["required/level"] = 19,
	["required/class"] = "shen",
	max_damage = 106,
	value = 2850,
}


