ITEMINFO = {
	--icon = 98,--45,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "毒澜帽",
	["required/level"] = 66,
	--["required/gender"] = "男性",
	max_mp = 350,
	value = 9900,
}


