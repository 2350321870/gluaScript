ITEMINFO = {
	icon = 391,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "名花衫",
	["required/level"] = 1,
	defense = 2,
	value = 150,

}


