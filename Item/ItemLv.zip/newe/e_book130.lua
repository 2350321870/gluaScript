ITEMINFO = {
	list_icon = 29,
	type = "book",
	wield_position = 2,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "@2武经[+9]@0",
	["required/level"] = 65,
	["required/class"] = "xian",
	max_damage = 67,
	defense = 12,
	max_mp = 77,
	max_hp = 42,
	int = 11,
	value = 9750,
}


