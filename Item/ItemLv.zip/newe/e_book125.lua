ITEMINFO = {
	list_icon = 29,
	type = "book",
	wield_position = 2,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "@2武经[+4]@0",
	["required/level"] = 65,
	["required/class"] = "xian",
	max_damage = 62,
	defense = 7,
	max_mp = 37,
	int = 6,
	value = 9750,
}


