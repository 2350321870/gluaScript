ITEMINFO = {
	icon = 1520,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "赤魂",
	["required/level"] = 65,
	["required/class"] = "shen",
	max_damage = 304,
	value = 9750,
}


