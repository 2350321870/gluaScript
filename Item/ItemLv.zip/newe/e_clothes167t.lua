ITEMINFO = {
	icon = 406,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "纵横袍",
	["required/level"] = 50,
	BindType = "ImmediatelyBind",
        useful_time_get=7200,
	dresstype = "703",
	dresscolor = 0,
	defense = 43,
	value = 7500,
	offer=400,  --购买需要帮贡
}


