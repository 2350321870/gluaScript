ITEMINFO = {
	--icon = 98,--29,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "远游冠",
	["required/level"] = 42,
	--["required/gender"] = "男性",
	max_mp = 230,
	value = 6300,
}


