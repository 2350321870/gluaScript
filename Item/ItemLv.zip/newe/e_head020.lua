ITEMINFO = {
	icon = 39,
	icon_f = 40,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "玄火冠",
	["required/level"] = 58,
	--["required/gender"] = "男性",
	max_mp = 305,
	defense = 43,
	value = 8700,
}


