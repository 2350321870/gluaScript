ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "玄武耳环",
	["required/level"] = 70,
	BindType = "Used_Bind",
	dresstype = "702",
	dresscolor = 0,
	max_hp = 420,
	str = 41,
	value = 10500,
}


