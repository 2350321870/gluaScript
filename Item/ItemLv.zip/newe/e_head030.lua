ITEMINFO = {
	icon = 59,
	icon_f = 60,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "邪神战盔",
	["required/level"] = 88,
	--["required/gender"] = "男性",
	max_mp = 455,
	defense = 88,
	value = 13200,
}


