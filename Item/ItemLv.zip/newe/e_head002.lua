ITEMINFO = {
	icon = 3,
	icon_f = 4,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "百茗巾",
	["required/level"] = 4,
	--["required/gender"] = "男性",
	max_mp = 35,
	defense = 4,
	value = 600,
}


