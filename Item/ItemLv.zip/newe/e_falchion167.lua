ITEMINFO = {
	icon = 1518,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "纵横刀",
	["required/level"] = 50,
	["required/class"] = "shen",
	BindType = "ImmediatelyBind",
	dresstype = "703",
	dresscolor = 0,
	max_damage = 290,
	value = 7500,
	offer=900,  --购买需要帮贡
}


