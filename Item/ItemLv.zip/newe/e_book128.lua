ITEMINFO = {
	list_icon = 29,
	type = "book",
	wield_position = 2,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "@2武经[+7]@0",
	["required/level"] = 65,
	["required/class"] = "xian",
	max_damage = 65,
	defense = 10,
	max_mp = 61,
	max_hp = 32,
	int = 9,
	value = 9750,
}


