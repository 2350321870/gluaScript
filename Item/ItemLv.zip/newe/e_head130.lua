ITEMINFO = {
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "@2紫阳冠[+9]@0",
	["required/level"] = 65,
	max_mp = 70,
	max_hp = 357,
	str = 12,
	dex = 11,
	int = 12,
	value = 9750,
}


