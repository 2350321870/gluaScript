ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "勇者耳环",
	["required/level"] = 70,
	dresstype = "701",
	dresscolor = 0,
	max_hp = 420,
	str=41,
	value = 10500,
}


