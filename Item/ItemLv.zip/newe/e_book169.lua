ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "圣灵天书",
	["required/level"] = 70,
	["required/class"] = "xian",
	BindType = "ImmediatelyBind",
	dresstype = "705",
	dresscolor = 0,
	max_damage = 90,
	no_bothhands = 1,
	value = 10500,
	offer=1100,  --购买需要帮贡
}


