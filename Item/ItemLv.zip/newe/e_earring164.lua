ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "啸天耳环",
	["required/level"] = 80,
	BindType = "Used_Bind",
	dresstype = "804",
	dresscolor = 2,
	max_hp = 450,
	str=52,
	value = 12000,
}


