ITEMINFO = {
	icon = 402,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "幸运袍",
	["required/level"] = 50,
	BindType = "Used_Bind",
	dresstype = "501",
	dresscolor = 0,
	defense = 55,
	value = 7500,

}


