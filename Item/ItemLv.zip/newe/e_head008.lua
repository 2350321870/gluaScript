ITEMINFO = {
	icon = 15,
	icon_f = 16,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "血幽盔",
	["required/level"] = 22,
	--["required/gender"] = "男性",
	max_mp = 125,
	defense = 11,
	value = 3300,
}


