ITEMINFO = {
	icon = 45,
	icon_f = 46,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "苍月盔",
	["required/level"] = 67,
	--["required/gender"] = "男性",
	max_mp = 350,
	defense = 55,
	value = 10050,
}


