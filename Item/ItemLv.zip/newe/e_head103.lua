ITEMINFO = {
	--icon = 21,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "战士新秀盔",
	["required/level"] = 10,
	--["required/gender"] = "男性",
	["required/class"] = "shen",
	max_mp = 65,
	value = 1500,
}


