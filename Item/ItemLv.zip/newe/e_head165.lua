ITEMINFO = {
	icon = 24,
	icon_f = 24,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "醉银冠",
	["required/level"] = 20,
	BindType = "ImmediatelyBind",
	--["required/gender"] = "男性",
	dresstype = "20",
	dresscolor = 0,
	max_mp = 110,
	defense = 9,
	value = 3000,
}


