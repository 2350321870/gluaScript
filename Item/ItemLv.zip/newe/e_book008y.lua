ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "吴越传奇",
	["required/level"] = 58,
	["required/class"] = "xian",
	max_damage = 53,
	no_bothhands = 1,
	value = 8700,

}


