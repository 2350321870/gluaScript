ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "@2虹光耳环[+6]@0",
	["required/level"] = 65,
	max_damage = 6,
	defense = 17,
	max_mp = 360,
	max_hp = 80,
	str = 8,
	value = 9750,
}


