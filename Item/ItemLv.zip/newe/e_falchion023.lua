ITEMINFO = {
	icon = 1523,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "青阳",
	["required/level"] = 74,
	["required/class"] = "shen",
	max_damage = 344,
	value = 11100,
}


