ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "凯旋书",
	["required/level"] = 80,
	["required/class"] = "xian",
	BindType = "Used_Bind",
	dresstype = "803",
	dresscolor = 2,
	max_damage = 76,
	no_bothhands = 1,
	value = 12000,
	
}


