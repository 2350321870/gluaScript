ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "史记",
	["required/level"] = 69,
	["required/class"] = "xian",
	max_damage = 62,
	no_bothhands = 1,
	value = 10350,

}


