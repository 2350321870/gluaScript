ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "破军耳环",
	["required/level"] = 80,
	BindType = "Used_Bind",
	dresstype = "802",
	dresscolor = 2,
	max_hp = 500,
	str=52,
	value = 12000,
}


