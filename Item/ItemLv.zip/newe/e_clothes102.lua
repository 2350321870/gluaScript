ITEMINFO = {
	icon = 0,
	icon_f = 0,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "侠客新秀铠",
	["required/level"] = 10,
	["required/class"] = "wu",
	defense = 8,
	value = 1500,
	
}


