ITEMINFO = {
	icon = 1506,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "@2御龙刀[+6]@0",
	["required/level"] = 65,
	["required/class"] = "shen",
	max_damage = 352,
	defense = 9,
	max_mp = 20,
	max_hp = 45,
	str = 9,
	value = 9750,
}


