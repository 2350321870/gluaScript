ITEMINFO = {
	list_icon = 19,
	wield_position = 2,
	type = "book",
	is_bag_item = 1,
	name = "武圣书",
	["required/level"] = 80,
	["required/class"] = "xian",
	dresstype = "802",
	dresscolor = 2,
	max_damage = 15,
	no_bothhands = 1,
	value = 12000,
	
}


