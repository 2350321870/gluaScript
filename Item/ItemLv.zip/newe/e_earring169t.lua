ITEMINFO = {
	list_icon = 30,
	type = "earring",
	wield_position = 8,
	is_bag_item = 1,
	name = "圣灵耳坠",
	["required/level"] = 70,
	BindType = "ImmediatelyBind",
        useful_time_get=7200,
	dresstype = "705",
	dresscolor = 0,
	max_hp = 300,
	str=43,
	value = 10500,
	offer=700,  --购买需要帮贡
}


