ITEMINFO = {
	icon = 392,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "百茗衫",
	["required/level"] = 4,
	defense = 4,
	value = 600,
	
}


