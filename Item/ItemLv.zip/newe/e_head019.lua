ITEMINFO = {
	icon = 37,
	icon_f = 38,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "玄冰冠",
	["required/level"] = 55,
	--["required/gender"] = "男性",
	max_mp = 290,
	defense = 39,
	value = 8250,
}


