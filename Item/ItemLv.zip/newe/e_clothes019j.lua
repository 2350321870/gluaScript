ITEMINFO = {
	icon = 393,
	icon_f = 409,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "天师御衣",
	["required/level"] = 54,
	defense = 55,
	value = 8100,
}


