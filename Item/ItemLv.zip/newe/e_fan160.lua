ITEMINFO = {
	icon = 1764,
	list_icon = 18,
	type = "fan",
	wield_position = 1,
	is_bag_item = 1,
	name = "豪杰扇",
	["required/level"] = 70,
	["required/class"] = "xian",
	BindType = "Used_Bind",
	dresstype = "703",
	dresscolor = 1,
	max_damage = 25,
	value = 10500,
}


