ITEMINFO = {
	list_icon = 29,
	type = "book",
	wield_position = 2,
	no_bothhands = 1,
	is_bag_item = 1,
	name = "@2武经[+3]@0",
	["required/level"] = 65,
	["required/class"] = "xian",
	max_damage = 61,
	defense = 6,
	max_mp = 29,
	int = 5,
	value = 9750,
}


