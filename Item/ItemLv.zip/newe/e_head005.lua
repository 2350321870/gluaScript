ITEMINFO = {
	icon = 9,
	icon_f = 10,
	list_icon = 24,
	type = "head",
	wield_position = 3,
	is_bag_item = 1,
	name = "化血盔",
	["required/level"] = 13,
	--["required/gender"] = "男性",
	max_mp = 80,
	defense = 7,
	value = 1950,
}


