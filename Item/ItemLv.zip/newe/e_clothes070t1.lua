ITEMINFO = {
	icon = 423,
	icon_f = 427,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "婵娟衣",
	BindType = "ImmediatelyBind",
	useful_time_get=604800,
	value = 200,
	--description = "霸王展霸气、虎年腾虎威",
}
