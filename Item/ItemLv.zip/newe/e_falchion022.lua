ITEMINFO = {
	icon = 1522,
	list_icon = 22,
	type = "falchion",
	wield_position = 1,
	is_bag_item = 1,
	name = "噬魂",
	["required/level"] = 71,
	["required/class"] = "shen",
	max_damage = 331,
	value = 10650,
}


