ITEMINFO = {
	icon = 404,
	icon_f = 411,
	list_icon = 26,
	type = "clothes",
	wield_position = 4,
	is_bag_item = 1,
	name = "天缘战甲",
	["required/level"] = 22,
	defense = 15,
	value = 3300,
	
}


